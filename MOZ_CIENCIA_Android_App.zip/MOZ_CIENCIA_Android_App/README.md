# MOZ CIÊNCIA — Projeto Android

Projeto inicial de uma aplicação Android que inclui o protótipo educativo 2D MOZ CIÊNCIA (Maputo, veículos e missões de Física/Química) no asset `app/src/main/assets/index.html`.

**Aviso:** este é o código-fonte, não um APK pronto a instalar. A compilação real ainda precisa de ser feita com Android Studio ou GitHub Actions e não foi testada num telemóvel nesta sessão. Consulte `LEIA-ME-PT.txt` para os passos.
